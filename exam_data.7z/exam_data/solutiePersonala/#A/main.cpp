#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <queue>
#include <algorithm>
#include <unordered_set>
#include <set>
#include <unordered_map>

using namespace std;

class Product {
public:
    string name;
    float productionPrice;
    // expiration date | quantity
    priority_queue <pair<int, float>, vector<pair<int,float>>, greater<pair<int, float>>> quantityByExpirationDate;
};

class Offer {
public:
    int date;
    string name;
    float price, quantity; 
};

class OfferSatisfied {
    public:
        string name;
        int quantitySold;
};


class Solutions {
public : 
    void A(unordered_map<string, Product>& productsByName, vector<Offer>& offers) {
        //gestionam toate ofertele cu un for
        vector<OfferSatisfied> offersTook;
        int madeMoney = 0;
        for (int i = 0; i < offers.size(); i++) {
            Offer* currentOffer = &offers[i];

            // ii vindem ce avem din oferta respectiva daca : 
            // exista produsul in stoc && pretul este macar egal cu cel de productie

            if (!productsByName.contains(currentOffer->name)) {
                continue;
            }
            if (currentOffer->price < productsByName[currentOffer->name].productionPrice) {
                continue;
            }

            for (int j = 0; j < productsByName[currentOffer->name].quantityByExpirationDate.size(); j++) {
                float parsedQuantity = 0;

                priority_queue <pair<int, float>, vector<pair<int, float>>, greater<pair<int, float>>> copyQuantityByExpirationDate
                    = productsByName[currentOffer->name].quantityByExpirationDate;
                float foundQuantity = 0;
                int stillRemainingExpiredForCurrentOffer = 0;

                vector<pair<int, float>> expiredForOffer;
                while ((copyQuantityByExpirationDate.size() > stillRemainingExpiredForCurrentOffer) && foundQuantity < currentOffer->quantity) {
                    pair<int, float> currentPair = copyQuantityByExpirationDate.top();

                    // daca e expirat, sa l scot din coada 
                    if (currentPair.first >= currentOffer->date) {
                        //expiration check
                        stillRemainingExpiredForCurrentOffer++;
                        copyQuantityByExpirationDate.pop();
                        expiredForOffer.push_back(currentPair);
                        continue;
                    }

                    int stillNeeded = currentOffer->quantity; 
                    if (stillNeeded >= currentPair.second) {
                        foundQuantity += currentPair.second;
                        currentPair.second = 0;
                        madeMoney += currentPair.second * currentOffer->price;
                        copyQuantityByExpirationDate.pop();
                    }
                    else {
                        foundQuantity += currentPair.second;
                        currentPair.second -= stillNeeded;
                        madeMoney += stillNeeded * currentOffer->price;
                    }
                }
                if(foundQuantity != 0)
                    offersTook.push_back(OfferSatisfied(currentOffer->name, foundQuantity));

                //aici am ramas.
                    for (auto& pair : expiredForOffer) {
                        copyQuantityByExpirationDate.push(pair);
                    }
                //

                productsByName[currentOffer->name].quantityByExpirationDate = copyQuantityByExpirationDate;
            }
        }

        
        for (OfferSatisfied offer : offersTook) {
            cout << offer.name << " " << offer.quantitySold << endl;
        }
        cout << madeMoney;
    }
    void B() {}
};

static string FILE_NAME = "Input.txt";

int main()
{
    ifstream inFile(FILE_NAME);
    Solutions solutions = Solutions();

    int incasari = 0;
    
    unordered_map<string, Product> productsByName;
    int noStocProducts;
    inFile >> noStocProducts;
    
    string name;
    float productionPrice;
    pair<int, float> quantityByExpirationDate;
    priority_queue<pair<int, float>> priorityQueue;
    for (int i = 0; i < noStocProducts; i++) {
        inFile >> name >> productionPrice >> quantityByExpirationDate.second >> quantityByExpirationDate.first;

        Product currentProduct = Product(name, productionPrice);
        currentProduct.quantityByExpirationDate.push(quantityByExpirationDate);

        if(productsByName.find(name) == productsByName.end())
        {
            productsByName[name] = currentProduct;
            continue;
        }
        productsByName[name].quantityByExpirationDate.push(quantityByExpirationDate);
    }

    int noOffers;
    inFile >> noOffers;

    vector<Offer> offers;
    for (int i = 0; i < noOffers; i++) {
        int offerDate, offerNoProducts;
        inFile >> offerDate >> offerNoProducts;

        for (int j = 0; j < offerNoProducts; j++) {
            Offer currentOffer = Offer();

            currentOffer.date = offerDate;
            inFile >> currentOffer.name >> currentOffer.price >> currentOffer.quantity;
            offers.push_back(currentOffer);
        }
    }
    solutions.A(productsByName, offers);
//    solutions.B();

    return 0;
}